WITH 
    EXPEDITION_DISPARADOR AS(
        SELECT
                               CODIGO_PERSONA,
                               SALDO_HOY,
                               SALDO_AYER,
                               FECHA_DESCUBIERTO,
                               IND_RECEPTORA_NOMINA,
                               IND_RECEPTORA_PENSION,
                               IND_RECEPTORA_DESEMPLEO,
                               IMPORTE_LIMITE_DESCUBIERTO
                               FROM 
                               (select CAVT20 AS SALDO_HOY,
                               COPEMK AS CODIGO_PERSONA,
                               FEVAIG AS FECHA_DESCUBIERTO,
                               INZ120 AS IND_RECEPTORA_NOMINA,
                               INZ121 AS IND_RECEPTORA_PENSION,
                               INZ122 AS IND_RECEPTORA_DESEMPLEO,
                               IMLIMK AS IMPORTE_LIMITE_DESCUBIERTO,
                               XCOEMP, 
                               COPSER,
                               IDCOEC,
                               IDPRIG
                               FROM  STANDARD.IGV0_CP_AHCA_D
                               WHERE SNAPSHOT='LATEST'AND EXTRACTIONDATE = date_format(date_sub(current_date(),1), 'yyyyMMdd')  AND CAVT20 < 0 AND COSIIG = 10000 AND FEIGFI IS NULL AND FFIGCO IS NULL  AND XCOEMP = 0) AS A 
                               LEFT JOIN
                               (SELECT CAVT20 as SALDO_AYER, XCOEMP, COPSER, IDCOEC,IDPRIG 
                               FROM STANDARD.IGV0_CP_AHCA_D
                               WHERE SNAPSHOT = 'HISTORIC'  AND EXTRACTIONDATE = date_format(date_sub(current_date(),2), 'yyyyMMdd') AND COSIIG = 10000 AND FEIGFI IS NULL AND FFIGCO IS NULL  AND XCOEMP = 0 AND CAVT20 > 0 ) AS B
                               ON A.XCOEMP = B.XCOEMP AND A.COPSER = B.COPSER AND A.IDCOEC = B.IDCOEC AND A.IDPRIG = B.IDPRIG
                               INNER JOIN 
                               (SELECT COPEMK
                               FROM STANDARD.MKTBBLON 
                               WHERE SNAPSHOT='LATEST' AND COTPMK = 1) AS TABLON
                               ON A.CODIGO_PERSONA = TABLON.COPEMK
                               WHERE SALDO_AYER > 0
                               ),
                                  EXPEDITION_DATE_MODELOS AS(
        SELECT 'TB1_MODELOPROPENMIN' AS C1, MAX(EXTRACTIONDATE) AS C2 FROM STANDARD.MODELOPROPENMIN WHERE SNAPSHOT = 'LATEST')
SELECT
A.*,
TOTAL_SALDO_DISPONIBLE_CUENTAS_BANKIA,
MAX_LIMITE_DISPONIBLE_TARJ_CRED,
IMPORTE_LPP,
VIGENCIA_LPP,
CASE WHEN PROPENSION_LPP_SAS = 1 OR PROPENSION_LPP_BD = 1 THEN 1 ELSE 0 END AS PROPENSION_CONTRATACION_PRESTAMO

FROM 
EXPEDITION_DISPARADOR AS A 

LEFT JOIN
(
SELECT 
CUENTAS.COPEMK,
-- Hacemos el sumatorio de todas las cuentas, ya que nos interesa conocer su saldo final, si resulta ser positivo es que puede cubrir el descubierto con el saldo que tenga en otras cuentas
SUM(CUENTAS.CAVT20) AS TOTAL_SALDO_DISPONIBLE_CUENTAS_BANKIA
FROM 
 EXPEDITION_DISPARADOR 
 LEFT JOIN 
 (SELECT 
 COPEMK,
COPSER,
IDPRIG,
XCOEMP,
COSIIG
FROM 
 STANDARD.IGV0_CONTRATO_P
WHERE SNAPSHOT = 'LATEST' AND COPRBS = 20 AND XCOEMP = 0  AND FFIGCO IS NULL AND COSIIG = 10000
) AS CONTRATOS
ON EXPEDITION_DISPARADOR.CODIGO_PERSONA = CONTRATOS.COPEMK
LEFT JOIN
(SELECT
COPEMK,
XCOEMP, 
 COPSER,
IDCOEC,
IDPRIG,
CAVT20
FROM
STANDARD.IGV0_CP_AHCA_D
WHERE SNAPSHOT='LATEST' AND COSIIG = 10000 AND FEIGFI IS NULL AND FFIGCO IS NULL  AND XCOEMP = 0) AS CUENTAS 
 ON EXPEDITION_DISPARADOR.CODIGO_PERSONA = CUENTAS.COPEMK AND CONTRATOS.COPSER = CUENTAS.COPSER AND CONTRATOS.IDPRIG = CUENTAS.IDPRIG AND CONTRATOS.XCOEMP = CUENTAS.XCOEMP
GROUP BY CUENTAS.COPEMK
) AS C
ON A.CODIGO_PERSONA = C.COPEMK
LEFT JOIN
(SELECT COPEMK,
MAX(CACV0D) AS MAX_LIMITE_DISPONIBLE_TARJ_CRED
FROM STANDARD.IGV0_TARJETA_D
WHERE 
SNAPSHOT='LATEST' AND CACV0D > 0 AND COSIIG = 10000 AND FEIGFI IS NULL AND FFIGCO IS NULL  AND XCOEMP = 0 AND TRIM(TITAR3) = 'C' AND PORCPA= 100
GROUP BY 
COPEMK
) AS D
ON A.CODIGO_PERSONA = D.COPEMK
LEFT JOIN 
(select copemk, 
IMLPPM AS IMPORTE_LPP,
MAX(FECLPP) AS VIGENCIA_LPP
from STANDARD.IGV0_LPRESPRE_D 
where SNAPSHOT='LATEST' and XCOEMP = 0 AND FEIGFI IS NULL AND FFIGCO IS NULL AND COSIIG = 10000 AND TRIM(COELPP) = 'AC' AND TRIM(COESPQ)='VI' AND TRIM( CDTCLS) <>'99' and copser=93010  
GROUP BY copemk,IMLPPM ) AS E 
ON A.CODIGO_PERSONA = E.COPEMK
LEFT JOIN
(SELECT IDPERS, 
1 AS PROPENSION_LPP_SAS
FROM (SELECT IDPERS, nupropen FROM standard.crpropen AS CRP
WHERE  CRP.IDMODE='PCONSLPP02' AND CRP.extractiondate  in ( SELECT max(C2) FROM EXPEDITION_DATE_MODELOS )  ) AS crpropension,
(select idmode,
iduso,
nupropenmin
from 
standard.modelopropenmin AS MOP
WHERE MOP.idmode = 'PCONSLPP02' AND MOP.iduso='MEDICION' AND MOP.extractiondate in ( SELECT max(C2) FROM EXPEDITION_DATE_MODELOS )  ) AS propension  
WHERE 
 crpropension.nupropen>= propension.nupropenmin
GROUP BY IDPERS) AS F
ON A.CODIGO_PERSONA = F.IDPERS
LEFT JOIN
(SELECT CO_CLIENTE,
1 AS PROPENSION_LPP_BD
FROM ( select CO_CLIENTE,probabilidad  from derivatives_models_in.bgmd_in_matriz_propensiones AS  MP
where MP.modelid='MCOCLFX1' AND MP.sessionid in ( SELECT max(C2) FROM EXPEDITION_DATE_MODELOS) ) AS MATRIZ_PROP,
(select nupropenmin
FROM standard.modelopropenmin AS MP2
WHERE MP2.iduso='MEDICION' AND MP2.IDMODE ='MCOCLFX1' AND MP2.extractiondate in ( SELECT max(C2) FROM EXPEDITION_DATE_MODELOS ) ) AS MODELO_PROPENSION  
WHERE  MATRIZ_PROP.probabilidad>= MODELO_PROPENSION.nupropenmin
GROUP BY CO_CLIENTE ) AS G 
ON A.CODIGO_PERSONA = G.CO_CLIENTE
;
